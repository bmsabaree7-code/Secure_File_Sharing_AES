from app import app, init_db, cleanup_expired
init_db(); cleanup_expired()
print('\n=== SecureShare Advanced ===')
print('Open: http://127.0.0.1:5000')
print('Admin: admin / Admin@123')
app.run(host='127.0.0.1', port=5000, debug=True)
