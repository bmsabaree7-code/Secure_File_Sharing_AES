import os, sqlite3, secrets, hashlib, threading, time, json
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'database.db'
ENC_DIR = BASE_DIR / 'storage' / 'encrypted'
DOWNLOAD_DIR = BASE_DIR / 'storage' / 'downloads'
ENC_DIR.mkdir(parents=True, exist_ok=True); DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'change-this-demo-secret-key-please')
app.config['MAX_CONTENT_LENGTH'] = 25 * 1024 * 1024
OTP_EXPIRY_SECONDS = 300


def now_utc(): return datetime.now(timezone.utc)
def iso(dt): return dt.isoformat()

def db():
    c = sqlite3.connect(DB_PATH); c.row_factory = sqlite3.Row; return c

def init_db():
    c = db()
    c.executescript('''
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user', created_at TEXT NOT NULL, last_login TEXT
    );
    CREATE TABLE IF NOT EXISTS files (
      id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL,
      original_name TEXT NOT NULL, stored_name TEXT UNIQUE NOT NULL,
      sha256 TEXT NOT NULL, size INTEGER NOT NULL, password_protected INTEGER NOT NULL DEFAULT 0,
      salt BLOB NOT NULL, created_at TEXT NOT NULL,
      FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS shares (
      id INTEGER PRIMARY KEY AUTOINCREMENT, file_id INTEGER NOT NULL,
      token_hash TEXT UNIQUE NOT NULL, expires_at TEXT NOT NULL,
      password_hash TEXT, allowed_username TEXT, max_downloads INTEGER NOT NULL DEFAULT 5,
      download_count INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY(file_id) REFERENCES files(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS access_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, file_id INTEGER,
      share_id INTEGER, action TEXT NOT NULL, ip TEXT, details TEXT, created_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
      FOREIGN KEY(file_id) REFERENCES files(id) ON DELETE SET NULL
    );
    ''')
    # Upgrade older DBs created by the original project.
    cols = {r['name'] for r in c.execute('PRAGMA table_info(users)').fetchall()}
    if 'email' not in cols:
        c.execute("ALTER TABLE users ADD COLUMN email TEXT DEFAULT ''")
        rows = c.execute('SELECT id,username FROM users').fetchall()
        for r in rows: c.execute('UPDATE users SET email=? WHERE id=?', (f"{r['username']}@demo.local", r['id']))
    # Ensure demo admin exists.
    if not c.execute('SELECT id FROM users WHERE username=?', ('admin',)).fetchone():
        c.execute('INSERT INTO users(username,email,password_hash,role,created_at) VALUES(?,?,?,?,?)',
                  ('admin','admin@demo.local',generate_password_hash('Admin@123'),'admin',iso(now_utc())))
    c.commit(); c.close()

def csrf_token():
    if 'csrf' not in session: session['csrf'] = secrets.token_urlsafe(24)
    return session['csrf']
app.jinja_env.globals['csrf_token'] = csrf_token

@app.before_request
def security_and_cleanup():
    if request.method == 'POST' and request.endpoint not in ('static',):
        supplied = request.form.get('_csrf','')
        if not secrets.compare_digest(supplied, session.get('csrf','')):
            abort(400, description='Invalid security token. Refresh and try again.')
    if request.endpoint not in ('static',):
        try: cleanup_expired()
        except Exception as e: app.logger.warning('cleanup: %s', e)

def log_access(user_id, file_id, action, share_id=None, details=''):
    c=db(); c.execute('INSERT INTO access_logs(user_id,file_id,share_id,action,ip,details,created_at) VALUES(?,?,?,?,?,?,?)',
      (user_id,file_id,share_id,action,request.remote_addr or 'unknown',details,iso(now_utc()))); c.commit(); c.close()

def login_required(fn):
    @wraps(fn)
    def w(*a,**kw):
        if not session.get('user_id') or not session.get('twofa'):
            flash('Please complete login and OTP verification.','warning'); return redirect(url_for('login'))
        return fn(*a,**kw)
    return w

def admin_required(fn):
    @wraps(fn)
    def w(*a,**kw):
        if session.get('role')!='admin': abort(403)
        return fn(*a,**kw)
    return w

def derive_key(password, salt):
    return PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=390000).derive(password.encode())

def encrypt_bytes(data, password=None):
    salt=secrets.token_bytes(16); key=derive_key(password,salt) if password else secrets.token_bytes(32)
    nonce=secrets.token_bytes(12); return nonce + AESGCM(key).encrypt(nonce,data,None), salt, key

def decrypt_blob(blob, password=None, key=None):
    nonce, ct=blob[:12],blob[12:]; return AESGCM(key or derive_key(password, CURRENT_SALT)).decrypt(nonce,ct,None)

def cleanup_expired():
    c=db(); now=iso(now_utc())
    rows=c.execute('SELECT s.id,s.file_id,f.stored_name,s.revoked FROM shares s JOIN files f ON f.id=s.file_id WHERE s.expires_at<=? OR s.revoked=1',(now,)).fetchall()
    for r in rows:
        c.execute('DELETE FROM shares WHERE id=?',(r['id'],))
        left=c.execute('SELECT COUNT(*) c FROM shares WHERE file_id=?',(r['file_id'],)).fetchone()['c']
        if left==0:
            f=c.execute('SELECT stored_name FROM files WHERE id=?',(r['file_id'],)).fetchone()
            if f:
                for p in [ENC_DIR/f['stored_name'], ENC_DIR/(f['stored_name']+'.key')]:
                    try: p.unlink()
                    except FileNotFoundError: pass
            c.execute('DELETE FROM files WHERE id=?',(r['file_id'],))
    c.commit(); c.close()

def cleanup_loop():
    while True:
        try: cleanup_expired()
        except Exception as e: print('Cleanup error:',e)
        time.sleep(30)

@app.context_processor
def ui_context():
    return {'current_year': now_utc().year}

@app.route('/')
def index(): return render_template('index.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method=='POST':
        username=request.form.get('username','').strip(); email=request.form.get('email','').strip().lower(); password=request.form.get('password','')
        if len(username)<3 or len(password)<8 or '@' not in email: flash('Use a valid username, email and 8+ character password.','danger'); return redirect(url_for('register'))
        try:
            c=db(); c.execute('INSERT INTO users(username,email,password_hash,role,created_at) VALUES(?,?,?,?,?)',(username,email,generate_password_hash(password),'user',iso(now_utc()))); c.commit(); c.close()
            flash('Account created. Login to continue with OTP.','success'); return redirect(url_for('login'))
        except sqlite3.IntegrityError: flash('Username or email already exists.','danger')
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password',''); c=db(); user=c.execute('SELECT * FROM users WHERE username=?',(u,)).fetchone(); c.close()
        if not user or not check_password_hash(user['password_hash'],p): flash('Invalid credentials.','danger'); return redirect(url_for('login'))
        otp=f'{secrets.randbelow(1000000):06d}'; session.clear(); session['pending_user']=user['id']; session['pending_role']=user['role']; session['otp']=otp; session['otp_expires']=time.time()+OTP_EXPIRY_SECONDS; csrf_token()
        print(f'\n[SECURESHARE OTP] {u} -> {otp} (valid 5 minutes)\n'); flash('OTP generated. For this demo, copy it from the terminal.','info'); return redirect(url_for('verify_otp'))
    return render_template('login.html')

@app.route('/verify-otp', methods=['GET','POST'])
def verify_otp():
    if 'pending_user' not in session: return redirect(url_for('login'))
    if request.method=='POST':
        if time.time()>session.get('otp_expires',0): flash('OTP expired. Login again.','danger'); return redirect(url_for('login'))
        if not secrets.compare_digest(request.form.get('otp','').strip(),session.get('otp','')): flash('Invalid OTP.','danger'); return redirect(url_for('verify_otp'))
        uid=session['pending_user']; c=db(); user=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone(); c.execute('UPDATE users SET last_login=? WHERE id=?',(iso(now_utc()),uid)); c.commit(); c.close()
        session.clear(); session.update(user_id=user['id'],username=user['username'],role=user['role'],twofa=True); csrf_token(); log_access(uid,None,'LOGIN_2FA_SUCCESS'); return redirect(url_for('dashboard'))
    return render_template('verify_otp.html')

@app.route('/logout')
def logout(): session.clear(); flash('Logged out securely.','success'); return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    c=db(); files=c.execute('SELECT * FROM files WHERE owner_id=? ORDER BY id DESC',(session['user_id'],)).fetchall(); shares=c.execute('SELECT s.*,f.original_name FROM shares s JOIN files f ON f.id=s.file_id WHERE f.owner_id=? ORDER BY s.id DESC',(session['user_id'],)).fetchall(); logs=c.execute('SELECT l.*,f.original_name FROM access_logs l LEFT JOIN files f ON f.id=l.file_id WHERE l.user_id=? ORDER BY l.id DESC LIMIT 12',(session['user_id'],)).fetchall(); c.close()
    return render_template('dashboard.html',files=files,shares=shares,logs=logs)

@app.route('/upload', methods=['GET','POST'])
@login_required
def upload():
    if request.method=='POST':
        f=request.files.get('file'); fp=request.form.get('file_password') or None
        if not f or not f.filename: flash('Select a file.','danger'); return redirect(url_for('upload'))
        data=f.read(); original=secure_filename(f.filename) or 'uploaded_file'
        digest=hashlib.sha256(data).hexdigest(); encrypted,salt,key=encrypt_bytes(data,fp); stored=secrets.token_hex(24)+'.bin'; (ENC_DIR/stored).write_bytes(salt+encrypted)
        if not fp: (ENC_DIR/(stored+'.key')).write_bytes(key)
        c=db(); cur=c.execute('INSERT INTO files(owner_id,original_name,stored_name,sha256,size,password_protected,salt,created_at) VALUES(?,?,?,?,?,?,?,?)',(session['user_id'],original,stored,digest,len(data),1 if fp else 0,salt,iso(now_utc()))); fid=cur.lastrowid; c.commit(); c.close(); log_access(session['user_id'],fid,'FILE_ENCRYPTED',details=f'AES-256-GCM; SHA-256={digest}')
        flash('Encrypted and stored. AES-256-GCM + SHA-256 integrity record created.','success'); return redirect(url_for('dashboard'))
    return render_template('upload.html')

@app.route('/share/<int:file_id>', methods=['POST'])
@login_required
def create_share(file_id):
    c=db(); f=c.execute('SELECT * FROM files WHERE id=? AND owner_id=?',(file_id,session['user_id'])).fetchone()
    if not f: c.close(); abort(404)
    try: mins=max(1,min(10080,int(request.form.get('minutes','60')))); limit=max(1,min(100,int(request.form.get('max_downloads','5'))))
    except ValueError: c.close(); flash('Invalid expiry or download limit.','danger'); return redirect(url_for('dashboard'))
    share_pw=request.form.get('share_password') or None; allowed=request.form.get('allowed_username','').strip() or None; token=secrets.token_urlsafe(36); exp=now_utc()+timedelta(minutes=mins)
    c.execute('INSERT INTO shares(file_id,token_hash,expires_at,password_hash,allowed_username,max_downloads,created_at) VALUES(?,?,?,?,?,?,?)',(file_id,hashlib.sha256(token.encode()).hexdigest(),iso(exp),generate_password_hash(share_pw) if share_pw else None,allowed,limit,iso(now_utc()))); c.commit(); c.close(); log_access(session['user_id'],file_id,'SHARE_CREATED',details=f'Expiry={iso(exp)}; recipient={allowed or "any authenticated receiver"}')
    return render_template('share_created.html',share_url=url_for('shared_download',token=token,_external=True),expires=iso(exp),recipient=allowed or 'Any authenticated receiver')

@app.route('/share/<token>', methods=['GET','POST'])
def shared_download(token):
    th=hashlib.sha256(token.encode()).hexdigest(); c=db(); s=c.execute('SELECT s.*,f.original_name,f.stored_name,f.sha256,f.password_protected,f.salt,f.owner_id,u.username owner_username FROM shares s JOIN files f ON f.id=s.file_id JOIN users u ON u.id=f.owner_id WHERE s.token_hash=?',(th,)).fetchone()
    if not s: c.close(); abort(404)
    if now_utc()>=datetime.fromisoformat(s['expires_at']): c.close(); cleanup_expired(); return render_template('expired.html'),410
    if s['download_count']>=s['max_downloads']: c.close(); return render_template('expired.html',message='Download limit reached.'),403
    if request.method=='POST':
        if s['allowed_username'] and session.get('username')!=s['allowed_username']: c.close(); flash('This share is restricted to the specified receiver account. Login as that user first.','danger'); return redirect(url_for('shared_download',token=token))
        if s['password_hash'] and not check_password_hash(s['password_hash'],request.form.get('share_password','')): c.close(); flash('Incorrect share password.','danger'); return redirect(url_for('shared_download',token=token))
        path=ENC_DIR/s['stored_name']
        if not path.exists(): c.close(); return render_template('expired.html',message='Encrypted storage object is no longer available.'),404
        raw=path.read_bytes(); salt,encrypted=raw[:16],raw[16:]
        try:
            if s['password_protected']: plain=AESGCM(derive_key(request.form.get('file_password',''),salt)).decrypt(encrypted[:12],encrypted[12:],None)
            else: plain=AESGCM((ENC_DIR/(s['stored_name']+'.key')).read_bytes()).decrypt(encrypted[:12],encrypted[12:],None)
        except Exception: c.close(); flash('Decryption failed. Verify the file password.','danger'); return redirect(url_for('shared_download',token=token))
        if hashlib.sha256(plain).hexdigest()!=s['sha256']: c.close(); return render_template('expired.html',message='Integrity verification failed. Download blocked.'),422
        tmp=DOWNLOAD_DIR/(secrets.token_hex(16)+'_'+s['original_name']); tmp.write_bytes(plain); c.execute('UPDATE shares SET download_count=download_count+1 WHERE id=?',(s['id'],)); c.commit(); c.close(); log_access(session.get('user_id'),s['file_id'],'SHARED_DOWNLOAD',s['id'],f'Integrity OK; SHA-256={s["sha256"]}')
        return send_file(tmp,as_attachment=True,download_name=s['original_name'])
    c.close(); return render_template('shared_download.html',share=s)

@app.route('/share/<int:share_id>/revoke',methods=['POST'])
@login_required
def revoke_share(share_id):
    c=db(); s=c.execute('SELECT s.*,f.owner_id,f.id file_id FROM shares s JOIN files f ON f.id=s.file_id WHERE s.id=? AND f.owner_id=?',(share_id,session['user_id'])).fetchone()
    if not s: c.close(); abort(404)
    c.execute('UPDATE shares SET revoked=1 WHERE id=?',(share_id,)); c.commit(); c.close(); log_access(session['user_id'],s['file_id'],'SHARE_REVOKED',share_id); flash('Share revoked.','success'); return redirect(url_for('dashboard'))

@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    c=db(); users=c.execute('SELECT id,username,email,role,created_at,last_login FROM users ORDER BY id DESC').fetchall(); files=c.execute('SELECT f.*,u.username FROM files f JOIN users u ON u.id=f.owner_id ORDER BY f.id DESC').fetchall(); shares=c.execute('SELECT s.*,f.original_name,u.username owner FROM shares s JOIN files f ON f.id=s.file_id JOIN users u ON u.id=f.owner_id ORDER BY s.id DESC').fetchall(); logs=c.execute('SELECT l.*,u.username,f.original_name FROM access_logs l LEFT JOIN users u ON u.id=l.user_id LEFT JOIN files f ON f.id=l.file_id ORDER BY l.id DESC LIMIT 100').fetchall(); stats={'users':c.execute('SELECT COUNT(*) FROM users').fetchone()[0],'files':c.execute('SELECT COUNT(*) FROM files').fetchone()[0],'active_shares':c.execute('SELECT COUNT(*) FROM shares').fetchone()[0],'events':c.execute('SELECT COUNT(*) FROM access_logs').fetchone()[0]}; c.close(); return render_template('admin.html',users=users,files=files,shares=shares,logs=logs,stats=stats)

@app.errorhandler(413)
def too_large(e): return render_template('error.html',message='File exceeds the 25 MB demo limit.'),413
@app.errorhandler(403)
def forbidden(e): return render_template('error.html',message='Access denied.'),403

if __name__=='__main__':
    init_db(); cleanup_expired(); threading.Thread(target=cleanup_loop,daemon=True).start(); print('SecureShare Advanced starting at http://127.0.0.1:5000'); print('Admin: admin / Admin@123'); app.run(host='127.0.0.1',port=5000,debug=True)
