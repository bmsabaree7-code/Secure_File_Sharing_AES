# Secure File Sharing using AES-256 — Advanced

A college/demo-ready secure file sharing application built with Flask, SQLite and Python cryptography.

## Advanced flow
Register/Login -> OTP/2FA -> Dashboard -> AES-256-GCM File Encryption -> Local Secure Storage -> Time-Limited Share Link -> Receiver Authentication -> Decryption -> SHA-256 Integrity Check -> Secure Download -> Audit History.

## Included security features
- AES-256-GCM authenticated encryption
- PBKDF2-HMAC-SHA256 with 390,000 iterations for password-derived keys
- OTP/2FA login (demo OTP is printed in the terminal)
- Role-based access: user/admin
- Optional file password
- Optional share password
- Receiver username restriction
- Expiring links (1 minute to 7 days)
- Download limits
- Manual share revocation
- SHA-256 integrity verification before download
- Automatic expiry cleanup every 30 seconds
- Audit/access history with IP, action and timestamp
- Admin security dashboard with users/files/shares/events
- CSRF token protection for POST forms
- 25 MB demo upload limit

## Demo admin
Username: `admin`
Password: `Admin@123`

## One-command Windows run
Double-click `run.bat`.

Or in PowerShell:
```powershell
.\run.bat
```

Then open http://127.0.0.1:5000

## Manual run
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python run.py
```

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process Bypass` for the current terminal, then activate again. You can also skip activation and run `.\.venv\Scripts\python.exe run.py`.

## Important demo notes
- The application stores encrypted files under `storage/encrypted`.
- For non-password-protected files, a server-held key sidecar is used for this local demo. A production deployment should use AWS KMS/Azure Key Vault/GCP KMS or another managed key service.
- Cloudinary/S3 and PostgreSQL are deployment-scale alternatives; this ZIP is intentionally self-contained so it runs without cloud credentials.
