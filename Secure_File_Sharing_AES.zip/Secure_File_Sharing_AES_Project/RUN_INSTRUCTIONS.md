# SecureShare Advanced — Windows Terminal Run Guide

## 1. Requirements
- Windows 10/11
- Python 3.11 or newer
- PowerShell or Command Prompt

## 2. Fastest method
1. Extract the ZIP.
2. Open PowerShell in the extracted `Secure_File_Sharing_AES_Project` folder.
3. Run:

```powershell
.\run.bat
```

The script creates `.venv`, installs packages and starts the server.

Open:
`http://127.0.0.1:5000`

## 3. Manual method
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python run.py
```

If PowerShell blocks activation:
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\.venv\Scripts\Activate.ps1
```

Or skip activation:
```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run.py
```

## 4. Demo admin
Username: `admin`
Password: `Admin@123`

After login, the OTP appears in the terminal. Enter that 6-digit code on the OTP page.

## 5. Demonstration flow
### User A
Register -> Login -> OTP -> Dashboard -> Encrypt File -> Create Controlled Link.

Choose:
- Expiry: e.g. 30 minutes
- Max downloads: e.g. 3
- Receiver username: optional registered receiver username
- Share password: optional

### User B / Receiver
If a receiver username restriction was set, register/login as that username and complete OTP. Open the generated share link. Enter share password and file password when requested. The application verifies SHA-256 before returning the decrypted file.

### Admin
Login as `admin` -> OTP -> Security Admin.
The admin page shows users, roles, encrypted objects, active shares and audit history.

## 6. Advanced features implemented
- AES-256-GCM encryption
- PBKDF2-HMAC-SHA256 password-derived keys
- OTP / 2FA
- User/Admin role-based access
- Optional file password
- Optional share password
- Receiver username permission
- Expiring links
- Download limits
- Share revocation
- SHA-256 integrity verification
- Automatic expired-share and encrypted-file cleanup
- Access/download audit history
- CSRF protection on POST forms
- Security admin dashboard
- Responsive dark security UI

## 7. Important local-demo note
The project uses local encrypted storage and SQLite so it can run without cloud credentials. For production, move encrypted objects to S3-compatible storage and keys to a managed KMS/Key Vault; use PostgreSQL for the database and HTTPS behind a reverse proxy.

## 8. Stop server
Press `Ctrl + C` in the terminal.
