function copyShare(){const x=document.getElementById('share');navigator.clipboard.writeText(x.value);const b=event.currentTarget;b.textContent='Copied ✓';setTimeout(()=>b.textContent='Copy',1500)}
setTimeout(()=>document.querySelectorAll('.flash').forEach(x=>x.classList.add('hide')),5000);
